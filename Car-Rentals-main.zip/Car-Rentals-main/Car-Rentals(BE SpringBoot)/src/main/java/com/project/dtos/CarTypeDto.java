package com.project.dtos;

import lombok.Data;

@Data
public class CarTypeDto {

    private Long id;

    private String description;

    private Integer price;

}
