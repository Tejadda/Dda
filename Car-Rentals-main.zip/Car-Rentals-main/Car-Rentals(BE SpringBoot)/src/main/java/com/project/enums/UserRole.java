package com.project.enums;
public enum UserRole {

    ADMIN,
    CUSTOMER

}

