package com.project.dtos;

import lombok.Data;

@Data
public class CarDealershipDto {
	
	private Long id;
    private String employee;
    private String dealership;

}
