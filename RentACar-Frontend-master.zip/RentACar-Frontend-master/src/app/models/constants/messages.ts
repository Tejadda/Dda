export const YouAreNotAuthorized = "Yetkiniz yok."
export const YouMustLoginFirst = "Önce giriş yapmalısınız."
export const FormIsMissing = "Form bilgileri eksik."

export const SaveYourCreditCard = "Ödeme bilginiz kaydedilsin mi?"
export const AreYouSureForDeleteThisImage = "Görseli silmek istediğinizden emin misiniz ? "
