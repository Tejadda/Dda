export interface CustomerReal{
  userId:number;
  companyName:string;
  findeksScore:number;
}
