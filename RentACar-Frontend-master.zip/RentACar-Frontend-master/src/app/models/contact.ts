export interface Contact{
  id:number;
  ad:string;
  ePosta:string;
  konu:string;
  mesaj:string;
}
