export interface Customer{
  customerId:number;
  userId:number;
  companyName:string;
}
