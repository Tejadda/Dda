export interface TokenModel{
  token:string;
  expiraiton:string;
}
