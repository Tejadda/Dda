export interface Brand{
  brandId:Number;
  brandName:string;
}
