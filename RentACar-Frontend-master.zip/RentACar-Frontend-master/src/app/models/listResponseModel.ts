export interface ListResponseModel<T>{
  data:T[];
}
