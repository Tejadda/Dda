export interface CartDetail{

}
