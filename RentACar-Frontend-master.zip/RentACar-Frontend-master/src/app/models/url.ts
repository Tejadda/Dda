export const BaseUrl = "https://localhost:44329/"
export const ApiUrl = BaseUrl + "api/"
