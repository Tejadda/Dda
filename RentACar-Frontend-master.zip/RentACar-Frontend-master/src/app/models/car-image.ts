export interface CarImage{
  carImageId:number;
  carId:number;
  imagePath:number;
  date:Date;
}
