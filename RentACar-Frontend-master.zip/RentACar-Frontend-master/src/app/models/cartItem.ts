import { CarDetail } from "./car-detail";

export class CartItem{
  cartId:number;
  carDetail:CarDetail;
  quantity:number;
  totalamount:number;
  payamount:number;
}
