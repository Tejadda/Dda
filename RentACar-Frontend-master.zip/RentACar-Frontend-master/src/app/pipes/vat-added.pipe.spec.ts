import { VatAddedPipe } from './vat-added.pipe';

describe('VatAddedPipe', () => {
  it('create an instance', () => {
    const pipe = new VatAddedPipe();
    expect(pipe).toBeTruthy();
  });
});
