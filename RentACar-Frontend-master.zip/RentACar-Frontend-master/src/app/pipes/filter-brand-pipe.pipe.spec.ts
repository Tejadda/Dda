import { FilterBrandPipePipe } from './filter-brand-pipe.pipe';

describe('FilterBrandPipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterBrandPipePipe();
    expect(pipe).toBeTruthy();
  });
});
