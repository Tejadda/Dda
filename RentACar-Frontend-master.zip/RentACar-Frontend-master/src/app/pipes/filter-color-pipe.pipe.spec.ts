import { FilterColorPipePipe } from './filter-color-pipe.pipe';

describe('FilterColorPipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterColorPipePipe();
    expect(pipe).toBeTruthy();
  });
});
